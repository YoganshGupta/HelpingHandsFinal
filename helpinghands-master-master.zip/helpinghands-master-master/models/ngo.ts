export class Ngo {
    constructor(
        
        public organisationName: String,
        public email: String,
        public address: String,
        public contact: String,
        public uname: String,
        public password: String
    )
    {}
}