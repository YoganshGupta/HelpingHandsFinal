export class Donator {
    constructor(
        public firstName: String,
        public lastName: String,
        public email: String,
        public address: String,
        public contact: String,
        public uname: String,
        public password: String
    )
    {}

}
