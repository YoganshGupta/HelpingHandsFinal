export class Stationary {
    constructor(
        public donorFirstName: String,
        public donorLastName: String,
        public donorEmail: String,
        public donorAddress: String,
        public donorContact: String,
        public donorUname: String,
        public stationaryType: String,
        public units: String,
        
        
    )
    {}

}
