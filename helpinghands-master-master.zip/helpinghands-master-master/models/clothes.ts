export class Clothes {
    constructor(
        public donorFirstName: String,
        public donorLastName: String,
        public donorEmail: String,
        public donorAddress: String,
        public donorContact: String,
        public donorUname: String,
        public clothesType: String,
        public clothesSize: String,
        public clothesWearer: String,
        public quantity: String
    )
    {}

}
