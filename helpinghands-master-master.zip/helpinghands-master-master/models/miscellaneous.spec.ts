import { Miscellaneous } from './miscellaneous';

describe('Miscellaneous', () => {
  it('should create an instance', () => {
    expect(new Miscellaneous()).toBeTruthy();
  });
});
