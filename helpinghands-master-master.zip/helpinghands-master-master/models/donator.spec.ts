import { Donator } from './donator';

describe('Donator', () => {
  it('should create an instance', () => {
    expect(new Donator()).toBeTruthy();
  });
});
