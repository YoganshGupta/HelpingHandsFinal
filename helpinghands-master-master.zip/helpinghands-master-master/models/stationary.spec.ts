import { Stationary } from './stationary';

describe('Stationary', () => {
  it('should create an instance', () => {
    expect(new Stationary()).toBeTruthy();
  });
});
