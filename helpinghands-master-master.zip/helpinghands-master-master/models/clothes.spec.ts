import { Clothes } from './clothes';

describe('Clothes', () => {
  it('should create an instance', () => {
    expect(new Clothes()).toBeTruthy();
  });
});
