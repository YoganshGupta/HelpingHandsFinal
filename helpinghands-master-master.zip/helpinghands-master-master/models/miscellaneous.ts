export class Miscellaneous {
    constructor(
    public donorFirstName: String,
    public donorLastName: String,
    public donorEmail: String,
    public donorAddress: String,
    public donorContact: String,
    public donorUname: String,
    public itemName: String,
    public quantity: String,
    public description: String){}
}
