import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signupgen',
  templateUrl: './signupgen.component.html',
  styleUrls: ['./signupgen.component.css']
})
export class SignupgenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
