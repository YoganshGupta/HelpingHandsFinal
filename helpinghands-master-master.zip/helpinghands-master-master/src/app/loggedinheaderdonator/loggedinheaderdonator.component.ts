import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loggedinheaderdonator',
  templateUrl: './loggedinheaderdonator.component.html',
  styleUrls: ['./loggedinheaderdonator.component.css']
})
export class LoggedinheaderdonatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
