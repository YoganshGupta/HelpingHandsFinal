import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logingen',
  templateUrl: './logingen.component.html',
  styleUrls: ['./logingen.component.css']
})
export class LogingenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
