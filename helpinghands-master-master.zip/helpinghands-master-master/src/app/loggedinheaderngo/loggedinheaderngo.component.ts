import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loggedinheaderngo',
  templateUrl: './loggedinheaderngo.component.html',
  styleUrls: ['./loggedinheaderngo.component.css']
})
export class LoggedinheaderngoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
